#!/bin/bash

scp -v -r *  pi@$1:/home/pi/appNode/public/blockly/modulesMicropython
